/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import core.chess.Chess;
import core.chess.board.Board;
import core.chess.pieces.Piece;
import core.person.Player;
import java.util.ArrayList;

/**
 *
 * @author goezs
 */
public class Main {
    
    public static void main(String[] args) {
        
        Player player1 = new Player("Arca");
        Player player2 = new Player("Motomami");
        Board board = new Board();
        ArrayList<Piece> pieces = Piece.generatePieces();
        Chess chess = new Chess(player1, player2, board, pieces);
        
        for(Piece piece : pieces){
            System.out.println(piece);
        }
        
    }
}
