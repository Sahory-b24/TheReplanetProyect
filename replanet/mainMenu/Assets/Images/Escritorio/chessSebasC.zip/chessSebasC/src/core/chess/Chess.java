/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package core.chess;

import core.chess.board.Board;
import core.chess.board.Position;
import core.chess.pieces.Piece;
import core.person.Player;
import java.util.ArrayList;

/**
 *
 * @author goezs
 */
public class Chess {
    
    public Chess(Player player1, Player player2, Board board, ArrayList<Piece> pieces) {
        this.player1 = player1;
        this.player2 = player2;
        this.board = board;
        this.pieces = pieces;
        
        this.player1.setChess(this);
        this.player2.setChess(this);
        this.board.setChess(this);
        for (Piece piece : this.pieces) {
            piece.setChess(this);
        }
        
    }    
    
    private Player player1;
    private Player player2;
    private ArrayList<Piece> pieces;
    private Board board;
    
    public void addPositions(ArrayList<Position> positions) {
        char[] columns = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'};

        for (int i = 0; i < 2; i++) {
            int row = (i == 0) ? 1 : 8;
            int pawnRow = (i == 0) ? 2 : 7;
            int blackset = i * 16;

            pieces.get(blackset).setPosition(findPosition(positions, row, 'E'));
            pieces.get(blackset + 1).setPosition(findPosition(positions, row, 'D'));

            for (int j = 0; j < 2; j++) {
                pieces.get(blackset + 2 + j * 3).setPosition(findPosition(positions, row, columns[j == 0 ? 2 : 5]));
                pieces.get(blackset + 3 + j * 3).setPosition(findPosition(positions, row, columns[j == 0 ? 1 : 6]));
                pieces.get(blackset + 4 + j * 3).setPosition(findPosition(positions, row, columns[j == 0 ? 0 : 7]));
            }

            for (int j = 0; j < 8; j++) {
                pieces.get(blackset + 8 + j).setPosition(findPosition(positions, pawnRow, columns[j]));
            }
        }
    }

    private Position findPosition(ArrayList<Position> positions, int row, char column) {
        for (Position pos : positions) {
            if (pos.getRow() == row && pos.getColumn().equals(String.valueOf(column))) {
                return pos;
            }
        }
        return null;
    }

}