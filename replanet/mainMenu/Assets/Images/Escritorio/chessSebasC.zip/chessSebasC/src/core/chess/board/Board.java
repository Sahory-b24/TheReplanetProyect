/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package core.chess.board;

import core.chess.Chess;
import java.util.ArrayList;

/**
 *
 * @author goezs
 */
public class Board {
    
    private ArrayList<Position> positions;
    private Chess chess;

    public Board() {
        this.positions = this.generatePositions();
    }

    public void setChess(Chess chess) {
        this.chess = chess;
    }
    
    private ArrayList<Position> generatePositions(){
        ArrayList<Position> positions = new ArrayList<>();
        
        // filas / row
        for (int i = 0; i < 8; i++) {
            
            // columnas / columns
            for (int j = 0; j < 8; j++) {
                
                int row = i + 1;
                String Column = "" + (char) (j + 65);
                boolean color = ( ( (i+j)%2 ) != 0 );
                positions.add(new Position(row, Column, color));
            }
        }
        
        return positions;
    }

    public ArrayList<Position> getPositions() {
        return positions;
    }
    
}
