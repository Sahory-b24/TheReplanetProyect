package core.person;

import core.chess.Chess;
import core.chess.board.Position;
import core.chess.pieces.Piece;

/**
 *
 * @author goezs
 */
public class Player {
    
    private String name;
    private Chess chess;

    public Player(String name) {
        this.name = name;
    }

    public void setChess(Chess chess) {
        this.chess = chess;
    }
    
    @Override
    public String toString() {
        return "Player{" + "name=" + name + '}';
    }
    
    public boolean movePiece(Piece piece, Position position){
        return true;
    }
}
