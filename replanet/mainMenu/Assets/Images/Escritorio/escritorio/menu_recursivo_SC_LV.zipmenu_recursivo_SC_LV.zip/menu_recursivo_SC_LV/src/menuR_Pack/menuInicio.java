package menuR_Pack;

/**
 *
 * @author goezs
 */
public class menuInicio extends javax.swing.JFrame {

    
    public menuInicio() {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("¡Hola, soy un menú!");
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        countchr = new javax.swing.JButton();
        sumOfDigits = new javax.swing.JButton();
        addod = new javax.swing.JButton();
        sum = new javax.swing.JButton();
        multiply = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        countchr1 = new javax.swing.JButton();
        MCD = new javax.swing.JButton();
        combi = new javax.swing.JButton();
        fact = new javax.swing.JButton();
        fibo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        countchr.setText("Contar \"A\"");
        countchr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                countchrActionPerformed(evt);
            }
        });

        sumOfDigits.setText("Sumatoria de digitos");
        sumOfDigits.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sumOfDigitsActionPerformed(evt);
            }
        });

        addod.setText("Sumar impares");
        addod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addodActionPerformed(evt);
            }
        });

        sum.setText("Sumatoria");
        sum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sumActionPerformed(evt);
            }
        });

        multiply.setText("Multiplicación");
        multiply.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                multiplyActionPerformed(evt);
            }
        });

        jButton1.setText("Salir");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        countchr1.setText("Potencia");
        countchr1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                countchr1ActionPerformed(evt);
            }
        });

        MCD.setText("Máximo Común Divisor");
        MCD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MCDActionPerformed(evt);
            }
        });

        combi.setText("Combinación");
        combi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combiActionPerformed(evt);
            }
        });

        fact.setText("Factorial");
        fact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                factActionPerformed(evt);
            }
        });

        fibo.setText("Fibonacci");
        fibo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fiboActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(fibo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 185, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(22, 22, 22))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(fact)
                            .addComponent(combi)
                            .addComponent(MCD)
                            .addComponent(countchr1)
                            .addComponent(multiply)
                            .addComponent(sum)
                            .addComponent(addod)
                            .addComponent(sumOfDigits)
                            .addComponent(countchr))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(multiply)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(sum)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(addod)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sumOfDigits)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(countchr)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(countchr1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(MCD)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(combi)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fact)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(16, 16, 16))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fibo)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void multiplyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_multiplyActionPerformed
        multiplyF m = new multiplyF();
        m.setVisible(true);
        dispose();
    }//GEN-LAST:event_multiplyActionPerformed

    private void sumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sumActionPerformed
        sumFrame m = new sumFrame();
        m.setVisible(true);
        dispose();
    }//GEN-LAST:event_sumActionPerformed

    private void addodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addodActionPerformed
        oddF m = new oddF();
        m.setVisible(true);
        dispose();
    }//GEN-LAST:event_addodActionPerformed

    private void sumOfDigitsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sumOfDigitsActionPerformed
        sumDigitsF m = new sumDigitsF();
        m.setVisible(true);
        dispose();
    }//GEN-LAST:event_sumOfDigitsActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void countchrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_countchrActionPerformed
        contA m = new contA();
        m.setVisible(true);
        dispose();
    }//GEN-LAST:event_countchrActionPerformed

    private void countchr1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_countchr1ActionPerformed
        potencia v = new potencia();
        v.setVisible(true);
        dispose();
    }//GEN-LAST:event_countchr1ActionPerformed

    private void MCDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MCDActionPerformed
        MCD v = new MCD();
        v.setVisible(true);
        dispose();
    }//GEN-LAST:event_MCDActionPerformed

    private void combiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combiActionPerformed
        combinacion v = new combinacion();
        v.setVisible(true);
        dispose();
    }//GEN-LAST:event_combiActionPerformed

    private void factActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_factActionPerformed
        factorial v = new factorial();
        v.setVisible(true);
        dispose();
    }//GEN-LAST:event_factActionPerformed

    private void fiboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fiboActionPerformed
        Fibonacci v = new Fibonacci();
        v.setVisible(true);
        dispose();
    }//GEN-LAST:event_fiboActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menuInicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton MCD;
    private javax.swing.JButton addod;
    private javax.swing.JButton combi;
    private javax.swing.JButton countchr;
    private javax.swing.JButton countchr1;
    private javax.swing.JButton fact;
    private javax.swing.JButton fibo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton multiply;
    private javax.swing.JButton sum;
    private javax.swing.JButton sumOfDigits;
    // End of variables declaration//GEN-END:variables
}
